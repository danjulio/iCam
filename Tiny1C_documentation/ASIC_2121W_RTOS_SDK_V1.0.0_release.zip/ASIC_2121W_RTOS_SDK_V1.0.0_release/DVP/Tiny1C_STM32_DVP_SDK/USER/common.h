#ifndef _COMMON_H_
#define _COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "falcon_cmd.h"
#include "delay.h"

#define LINE_SIZE (256*2)
#define COL_SIZE (192)
#define FRAME_SIZE (256*192*2)

#define SUCCESS 0
#define FAIL   -1


#define NORMAL
//#define UPDATE_FW

//#define IMAGE_AND_TEMP_OUTPUT			  
//#define IMAGE_OUTPUT
#define TEMP_OUTPUT

#define ENV_CORRECTION


#if defined(UPDATE_FW)
    #include "firmware.h"
#elif defined(NORMAL)
    #if defined(ENV_CORRECTION)
        #include "temperature.h"
    #endif
#endif




#ifdef __cplusplus
}
#endif

#endif

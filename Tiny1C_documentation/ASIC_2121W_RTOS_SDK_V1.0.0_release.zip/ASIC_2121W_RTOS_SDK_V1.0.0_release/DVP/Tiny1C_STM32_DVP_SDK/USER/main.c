#include "sys.h"

#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "ltdc.h"
#include "sdram.h"
#include "timer.h" 
#include "usart2.h"
#include "dcmi.h"
#include "mpu.h"
#include "i2c.h"
#include "yuv2rgb.h"
#include "common.h"
#include "cmd.h"

#define SDK_VERSION   "0.3.0"






u16 dcmi_line_buf[2][LINE_SIZE/2];	//RGB buf
u16 rgb_buf[LINE_SIZE/2];
u16 curline=0;							//����ͷ�������,��ǰ�б��
u16 yoffset=0;							//y�����ƫ����
u16 *pbuf=NULL;
u16 temp_buf[LINE_SIZE/2];
uint16_t center_temp=0;
float org_kelvin_temp=0;
float new_kelvin_temp=0;

#if defined(NORMAL)
void tiny1c_dcmi_rx_callback(void)
{  
	if(DMA2_Stream1->CR&(1<<19))//DMA???buf1,???buf0
	{ 
		pbuf=(u16*)dcmi_line_buf[0]; 
	}else 						//DMA???buf0,???buf1
	{
		pbuf=(u16*)dcmi_line_buf[1]; 
	} 	
	YUV422ToRGB565((u8*)pbuf, rgb_buf, LINE_SIZE/2);
	SCB_CleanInvalidateDCache();
	LTDC_Color_Fill(0,curline,LINE_SIZE/2-1,curline,rgb_buf);//DM2D??? 
#if defined(IMAGE_AND_TEMP_OUTPUT) 	
	if(curline<COL_SIZE*2-1)
	{
		curline++;
	}
#else
	if(curline<COL_SIZE-1)
	{
		curline++;
	}
#endif
	else
	{    
		curline=0;	
	}
}
void tiny1c_test(void)
{
	u16 outputheight;
	LCD_Clear(WHITE);
	POINT_COLOR=RED; 
	LCD_ShowString(30,50,200,16,16,"Apollo STM32F4/F7");
	LCD_ShowString(30,70,200,16,16,"Tiny1c yuv422 Mode"); 

	if(lcdltdc.pwidth!=0)	//RGB��
	{
		dcmi_rx_callback=tiny1c_dcmi_rx_callback;//RGB���������ݻص�����
        DCMI_DMA_Init((u32)dcmi_line_buf[0],(u32)dcmi_line_buf[1],LINE_SIZE/4,DMA_MDATAALIGN_HALFWORD,DMA_MINC_ENABLE);
	}

	TIM3->CR1&=~(0x01);	
	if(lcddev.height==1024)
	{
		yoffset=(lcddev.height-800)/2;
		outputheight=800;
	}else if(lcddev.height==1280)
	{
		yoffset=(lcddev.height-600)/2;
		outputheight=600;
	}else 
	{
		yoffset=0;
	}
	curline=yoffset;		//������λ
	printf("curline=%d\n",curline);
	DCMI_Start(); 			//��������
	LCD_Clear(BLACK);
	while(1)
	{
		handle_uart_cmd();
	}
}

int environment_correct_prepare(void)
{
#if defined(ENV_CORRECTION)
		FIL* fftemp;
		u8* read_data;
		int rst;
		u32 bread;
		u32 total,free;
		my_mem_init(SRAMIN);		    //��ʼ���ڲ��ڴ��
		my_mem_init(SRAMEX);		    //��ʼ���ⲿ�ڴ��
		my_mem_init(SRAMDTCM);		    //��ʼ��CCM�ڴ�� 

		fftemp=(FIL*)mymalloc(SRAMEX,sizeof(FIL));	//�����ڴ�	
		read_data=mymalloc(SRAMEX,sizeof(correct_table));//read_data���ֽڿռ�

		while(SD_Init())//��ⲻ��SD��
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Error!");
			delay_ms(500);					
			LCD_ShowString(30,150,200,16,16,"Please Check! ");
			delay_ms(500);
		}
		exfuns_init();							//Ϊfatfs��ر��������ڴ�				 
		f_mount(fs[0],"0:",1); 					//����SD�� 	  
		while(exf_getfree("0:",&total,&free))	//�õ�SD������������ʣ������
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Fatfs Error!");
			delay_ms(200);
			LCD_Fill(30,150,240,150+16,WHITE);	//�����ʾ			  
			delay_ms(200);
		}	
		rst=f_open(fftemp,"0:/tau_H.bin",FA_READ); 
		if(rst!=FR_OK)
		{
			printf("f_open tau_H failed\n");
			goto clean;
		}
		rst=f_read(fftemp,read_data,sizeof(correct_table),(UINT *)&bread);		//��ȡ����	
		if(rst!=FR_OK)
		{
			printf("f_read failed\n");
			goto clean;
		}
		memcpy(correct_table,read_data,sizeof(correct_table));
		printf("correct_table[start]=%d\n",correct_table[0]);
		printf("correct_table[end]=%d\n",correct_table[TAU_TABLE_SIZE-1]);
		f_close(fftemp);	
		read_nuc_parameter();
		calculate_org_env_cali_parameter();
		printf("nuc_table[0]=%d\n", nuc_table[0]);
		printf("EMS=%d\n", org_env_param.EMS);
		printf("TAU=%d\n", org_env_param.TAU);
		printf("TA=%d\n", org_env_param.Ta);
		printf("Tu=%d\n", org_env_param.Tu);
		printf("environment_correct_prepare success\n");
		return SUCCESS;
clean:
		myfree(SRAMEX,fftemp);	//�ͷ��ڴ�
		myfree(SRAMEX,read_data);	//�ͷ��ڴ�
		return FAIL;

#else
		return SUCCESS;
#endif
}

int main(void)
{
	#if defined(IMAGE_AND_TEMP_OUTPUT) 
		PreviewStartParam_t  preview_start_param={0,0,256,384,25,0};
	#else
		PreviewStartParam_t  preview_start_param={0,0,256,192,25,0};
	#endif
		u32 ret=0;

		Cache_Enable();                 //��L1-Cache
		MPU_Memory_Protection();        //��MPU����
		HAL_Init();				        //��ʼ��HAL��
		Stm32_Clock_Init(432,25,2,9);   //����ʱ��,216Mhz 
		delay_init(216);                //��ʱ��ʼ��
		uart_init(115200);		        //���ڳ�ʼ��
		LED_Init();                     //��ʼ��LED
		KEY_Init();                     //��ʼ������
		SDRAM_Init();                   //��ʼ��SDRAM
		LCD_Init();                     //��ʼ��LCD
		TIM3_Init(10000-1,10800-1);     //10Khz
		DCMI_Init();					//��ʼ��DCMI
		MX_I2C2_Init();                 //��ʼ��I2C
		vdcmd_init_by_type(VDCMD_I2C_VDCMD);

		POINT_COLOR=RED;//???????????? 
		//printf("start\n");
		LCD_ShowString(30,50,200,16,16,"Apollo STM32F4/F7");	
		LCD_ShowString(30,70,200,16,16,"Tiny1C TEST");	
		LCD_ShowString(30,90,200,16,16,"ATOM@ALIENTEK");
		LCD_ShowString(30,110,200,16,16,"2021/3/15");  	 
		while(KEY_Scan(0)!=KEY1_PRES)
		{
			LCD_ShowString(40,150,200,24,24,"KEY1: Start While!!");
		}
		environment_correct_prepare();
		

		LCD_ShowString(30,180,200,16,16,"Tiny1C OK");  
		printf("after dcmi init\n");
		ret=preview_start(&preview_start_param);
		printf("preview start result=%d\n",ret);
	#if defined(TEMP_OUTPUT) 
		y16_preview_start(PREVIEW_PATH0,Y16_MODE_TEMPERATURE);
	#endif
		if(ret!=HAL_OK)
			printf("start streaming failed error code=%d\n",ret);
		LCD_Clear(CYAN);
		tiny1c_test();
		return SUCCESS;
}


#elif defined(UPDATE_FW)

int main(void)
{
		int rst;
		u32 total,free;
		Cache_Enable();                 //��L1-Cache
		MPU_Memory_Protection();        //������ش洢����
		HAL_Init();				        //��ʼ��HAL��
		Stm32_Clock_Init(432,25,2,9);   //����ʱ��,216Mhz 
		delay_init(216);                //��ʱ��ʼ��
		uart_init(115200);		        //���ڳ�ʼ��
		//usmart_dev.init(108); 		    //��ʼ��USMART
		LED_Init();                     //��ʼ��LED
		KEY_Init();                     //��ʼ������
		SDRAM_Init();                   //��ʼ��SDRAM
		LCD_Init();                     //��ʼ��LCD
		//W25QXX_Init();				    //��ʼ��W25Q256
		my_mem_init(SRAMIN);		    //��ʼ���ڲ��ڴ��
		my_mem_init(SRAMEX);		    //��ʼ���ⲿ�ڴ��
		my_mem_init(SRAMDTCM);		    //��ʼ��CCM�ڴ�� 
		MX_I2C2_Init();                 //��ʼ��I2C
		
		POINT_COLOR=RED;
		LCD_ShowString(30,50,200,16,16,"Apollo STM32F4/F7"); 
		LCD_ShowString(30,70,200,16,16,"FATFS TEST");	
		LCD_ShowString(30,90,200,16,16,"ATOM@ALIENTEK");
		LCD_ShowString(30,110,200,16,16,"2016/7/15");	 	 
		LCD_ShowString(30,130,200,16,16,"Use USMART for test");	      
		while(SD_Init())//��ⲻ��SD��
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Error!");
			delay_ms(500);					
			LCD_ShowString(30,150,200,16,16,"Please Check! ");
			delay_ms(500);
			LED0_Toggle;//DS0��˸
		}
		vdcmd_init_by_type(VDCMD_I2C_VDCMD);

		//FTL_Init();
		exfuns_init();							//Ϊfatfs��ر��������ڴ�				 
		f_mount(fs[0],"0:",1); 					//����SD�� 
		LCD_Fill(30,150,240,150+16,WHITE);		//�����ʾ			  
		while(exf_getfree("0:",&total,&free))	//�õ�SD������������ʣ������
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Fatfs Error!");
			delay_ms(200);
			LCD_Fill(30,150,240,150+16,WHITE);	//�����ʾ			  
			delay_ms(200);
			LED0_Toggle;//DS0��˸
		}	
		while(KEY_Scan(0)!=KEY1_PRES)
		{
			LCD_ShowString(40,200,200,24,24,"KEY1:Start update");
		}	
		LCD_Fill(40,200,240,200+24,WHITE);	//�����ʾ												  			    
		POINT_COLOR=BLUE;//��������Ϊ��ɫ	   
		rst=update_firmware("0:/RS001_FW_new.bin");
		if(rst!=SUCCESS)
		{
			printf("update_firmware failed\n");
		}
		LCD_ShowString(30,170,200,16,16,"update finished!");	      
		while(1)
		{
			delay_ms(200);		 			   
		} 					  	       		  	       
	return 0;			  	       
}
#endif


#ifndef __YUV2RGB_H
#define __YUV2RGB_H		
#include "sys.h"

void YUV422ToRGB565(const u8 *yuv_buf, u16 *rgb_buf, int width);

#endif

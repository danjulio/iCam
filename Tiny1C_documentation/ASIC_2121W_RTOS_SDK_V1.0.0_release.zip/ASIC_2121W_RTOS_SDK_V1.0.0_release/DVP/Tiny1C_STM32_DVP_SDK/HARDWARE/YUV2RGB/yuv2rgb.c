#include "yuv2rgb.h"
#define RANGE_LIMIT(x) (x > 255 ? 255 : (x < 0 ? 0 : x))
 
void YUV422ToRGB565(const u8 *yuv_buf, u16 *rgb_buf, int width)
{
	int cols;
	int y, u, v, r, g, b;
	int y_pos,u_pos,v_pos;
 
 
	y_pos = 0;
	u_pos = 1;
	v_pos = 3;
 
	for (cols = 0; cols < width; cols++) {
		y = yuv_buf[y_pos];
		u = yuv_buf[u_pos] - 128;
		v = yuv_buf[v_pos] - 128;

		r = RANGE_LIMIT(y + v + ((v * 103) >> 8));
		g = RANGE_LIMIT(y - ((u * 88) >> 8) - ((v * 183) >> 8));
		b = RANGE_LIMIT(y + u + ((u * 198) >> 8));

		*rgb_buf++ = (((r & 0xf8) << 8) | ((g & 0xfc) << 3) | ((b & 0xf8) >> 3));

		y_pos += 2;

		if (cols & 0x01) {
			u_pos += 4;
			v_pos += 4;
		}
	}
}
 


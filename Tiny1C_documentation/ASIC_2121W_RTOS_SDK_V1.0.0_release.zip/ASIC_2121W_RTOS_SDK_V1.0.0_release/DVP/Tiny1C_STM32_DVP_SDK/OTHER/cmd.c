#include "cmd.h"
#include "temperature.h"


void PrintFloat(float value)
{
    int tmp,tmp1,tmp2;
    tmp = (int)value;
    tmp1=abs((int)((value-tmp)*10)%10);
    tmp2=abs((int)((value-tmp)*100)%10);
    printf("value=%d.%d%d\r\n",tmp,tmp1,tmp2);
}

void cmd_test(void)
{
	uint16_t shutter_vtemp;
    IrPoint_t point_pos={128,96};
	if(strcmp((const char*)USART_RX_BUF,"20")==0)
	{
		printf("USART_RX_BUF= %s\n",USART_RX_BUF);
		ooc_b_update(B_UPDATE);
	}
	else if(strcmp((const char*)USART_RX_BUF,"21")==0)
	{
		printf("USART_RX_BUF= %s\n",USART_RX_BUF);
		shutter_vtemp_get(&shutter_vtemp);
		printf("shutter vtemp=%d\n",shutter_vtemp);
	}
	else if(strcmp((const char*)USART_RX_BUF,"22")==0)
	{
		printf("USART_RX_BUF= %s\n",USART_RX_BUF);
		dpc_auto_calibration(5);
		printf("dpc_auto_calibration completed\n");
	}
    else if(strcmp((const char*)USART_RX_BUF,"24")==0)
    {
        calculate_new_env_cali_parameter(correct_table,0.8, 27, 27, 0.25, 1);
        tpd_get_point_temp_info(point_pos, &center_temp);
        org_kelvin_temp = (float)center_temp / 16;
		temp_calc_with_new_env_calibration(org_kelvin_temp, &new_kelvin_temp);
        printf("org_center_temp = %d\n",center_temp);
        printf("org_temp");
        PrintFloat(org_kelvin_temp - 273.15);
        printf("correct_temp");
		PrintFloat(new_kelvin_temp - 273.15);
    }
}

int handle_uart_cmd(void)
{
	    int len=0;
	    uint32_t k=0;

    	HAL_Delay(50);
		if(USART_RX_STA&0x8000)
		{					   
			len=USART_RX_STA&0x3fff;//得到此次接收到的数据长度
			printf("\r\nthe message is:\r\n");
			printf("%s\n",USART_RX_BUF);
			if(len>0)
			{
				cmd_test();
			}
			for(k=0;k<USART_REC_LEN;k++)
			{
				USART_RX_BUF[k]=0;
			}
			printf("\r\n\r\n");//插入换行
			USART_RX_STA=0;
		}
        return SUCCESS;
}




#ifndef _CMD_H_
#define _CMD_H_
#ifdef __cplusplus
extern "C" {
#endif



#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "usart2.h"


#include "falcon_cmd.h"
#include "common.h"

int handle_uart_cmd(void);

#endif

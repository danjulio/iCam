#ifndef _FIRMWARE_H_
#define _FIRMWARE_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "lcd.h"
#include "ff.h"
#include "common.h"
#include "mpu.h"
#include "sdmmc_sdcard.h"
#include "usmart.h"
#include "malloc.h"
#include "ff.h"
#include "exfuns.h"


#define DEV_STATUS_NULL 0
#define DEV_STATUS_ROM 1
#define DEV_STATUS_CACHE 2

#define MXIC_MANU_ID 0xC2
#define WINBOND_MANU_ID 0xEF
#define GIGADEVICE_MANU_ID 0xC8
#define SECTOR_LEN 4096

int update_firmware(const char* file_name);


#ifdef __cplusplus
}
#endif

#endif

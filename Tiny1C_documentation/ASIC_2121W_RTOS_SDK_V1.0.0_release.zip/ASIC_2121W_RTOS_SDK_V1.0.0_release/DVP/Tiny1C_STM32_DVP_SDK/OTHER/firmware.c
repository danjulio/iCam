#include "firmware.h"
int device_status_get()
{
	uint8_t status = 0;
	if (i2c_slave_read(0x000c, 1, &status) < 0)
	{
		printf("status=%d\n",status);
		return -1;
	}
	return status;
}

//flash switch to normal mode : QE bit disable
int flash_status_check()
{
	uint8_t flash_id[6];
	uint8_t status_val;
	int r =0;
	
	r = spi_read_id(flash_id);
	printf("spi_read_id:%d\r\n",r);
	if (flash_id[2] == MXIC_MANU_ID)
	{
		spi_write_status(0, 0);
		spi_read_status(0, &status_val);
		if (status_val == 0)
		{
			return SUCCESS;
		}
		return FAIL;
	}else if (flash_id[2] == WINBOND_MANU_ID)
	{
		spi_write_status(1, 0);
		spi_read_status(1, &status_val);
		if ((status_val == 0) || (status_val == 0x02))
		{
			return SUCCESS;
		}
		return FAIL;
	}
	else if (flash_id[2] == GIGADEVICE_MANU_ID)
	{
		spi_write_status(1, 0);
		spi_read_status(1, &status_val);
		if (status_val == 0)
		{
			return SUCCESS;
		}
		return FAIL;
	}
	return FAIL;
}


int update_firmware(const char* file_name)
{
    u8 res=0;	
    u16 i=0;
    int j=0;
    u16 k=0;
    FIL* fftemp;
    u8* write_data;
    u8* read_data;
    u8* erase_read_buff;
    u32 bread;
    uint32_t start_addr = 0;
    uint16_t sector_num = 64;		//  256K/4k = 64
    uint32_t addr = 0;
    int status,rst;
    u8 string[32]={0};
    fftemp=(FIL*)mymalloc(SRAMEX,sizeof(FIL));	//分配内存	
    read_data=mymalloc(SRAMEX,4096);				//分配4096个字节空间
    write_data=mymalloc(SRAMEX,4096);				//分配4096个字节空间
    erase_read_buff=mymalloc(SRAMEX,4096);	        //分配4096个字节空间
    res=f_open(fftemp,file_name,FA_READ); 
    if(res!=FR_OK)
        printf("f_open failed\n");
    status = device_status_get();
    if (status == DEV_STATUS_CACHE)
    {
        rst = sys_reset_to_update_fw();
        if (rst < 0)
        {
            printf("sys_reset_to_update_fw failed!\r\n");
            goto clean;
        }

        for (j = 0; j < 10000; j++)
        {
            status = device_status_get();
            if (status == DEV_STATUS_ROM)
            {
                break;
            }
            delay_ms(1);
        }
    }
    //2) reset spi status before spi access
    rst = flash_status_check();
    if (rst < 0)
    {
        printf("flash status check failed!\r\n");
        goto clean;
    }
    //3)erase and check erase area
    rst = spi_erase_sector(start_addr, sector_num);
    if (rst < 0)
    {
        printf("spi_erase_sector failed!\r\n");
        goto clean;
    }
        //check first 4k
    rst = spi_read(start_addr, SECTOR_LEN, erase_read_buff);
    if (rst < 0)
    {
        printf("spi_read first 4k failed!\r\n");
        goto clean;
    }
    for (j = 0; j < SECTOR_LEN; j++)
    {
        if (erase_read_buff[j] != 0xFF)
        {
            printf("flash first 4k check failed!\r\n");
            goto clean;
        }
    }
        //check last 4k
    rst = spi_read(start_addr + (sector_num - 1) * SECTOR_LEN, SECTOR_LEN, erase_read_buff);
    if (rst < 0)
    {
        printf("spi_read last 4k failed\r\n");
        goto clean;
    }
    for (j = 0; j < SECTOR_LEN; j++)
    {
        if (erase_read_buff[j] != 0xFF)
        {
            printf("flash last 4k check failed!\r\n");
            goto clean;
        }
    }

    for (k = 0; k < sector_num; k++)
    {
        printf("k:%d\r\n", k);
        res=f_read(fftemp,write_data,4096,(UINT *)&bread);		//读取数据	 
        if(res!=FR_OK)
        {
            printf("f_read failed\r\n");
            goto clean;
        }
        spi_write(addr, SECTOR_LEN, write_data);
        spi_read(addr, SECTOR_LEN, read_data);
        for (i = 0; i < SECTOR_LEN; i++)
        {
            if (write_data[i] != read_data[i])
            {
                printf("data compare failed!\r\n");
                goto clean;
            }
        }
        sprintf(string,"update progress %d\n",k*100/63);
        LCD_ShowString(30,150,200,16,16,string);	 
        addr += SECTOR_LEN;
    }
        
    //5)write cache tag
    spi_write_tag();
    //6)reboot rom
    sys_reset_to_rom();

    f_close(fftemp);
    printf("update finished!\r\n");
    myfree(SRAMEX,fftemp);	//释放内存
    myfree(SRAMEX,write_data);	//释放内存
    myfree(SRAMEX,read_data);	//释放内存
	return SUCCESS;
clean:
    myfree(SRAMEX,fftemp);	//释放内存
    myfree(SRAMEX,write_data);	//释放内存
    myfree(SRAMEX,read_data);	//释放内存
    return FAIL;
}
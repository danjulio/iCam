#include "sys.h"

#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "ltdc.h"
#include "sdram.h"
#include "mpu.h"
#include "i2c.h"
#include "spi.h"

#include "yuv2rgb.h"
#include "common.h"
#include "cmd.h"

#define SDK_VERSION   "0.3.0"

#define PRINT_TEMP

typedef enum{
	IMAGE_OUTPUT,
	TEMP_OUTPUT,
	IMAGE_AND_TEMP_OUTPUT,
}output_mode_t;


#define VOSPI_TX_DUMMY_LEN      (512)
#define VOSPI_ROW_SIZE			(256*2)
#define VOSPI_COL_SIZE			(192)





uint8_t byVospiTxDummuyBuf[VOSPI_TX_DUMMY_LEN];
uint8_t byVospiRxDummuyBuf[VOSPI_TX_DUMMY_LEN];
uint8_t byVospiTxBuf[VOSPI_TX_DUMMY_LEN];
uint8_t byVospiRxBuf[VOSPI_ROW_SIZE];
u16 rgb_buf[VOSPI_ROW_SIZE/2];
PreviewStartParam_t  preview_start_param;

uint16_t center_temp=0;
float org_kelvin_temp=0;
float new_kelvin_temp=0;

#if defined(NORMAL)

typedef HAL_StatusTypeDef(*spi_frame_get_func)(int frame_idx,int interval);
spi_frame_get_func spi_frame_get;

HAL_StatusTypeDef get_one_frame(int frame_idx,char spi_header_byte)
{
	HAL_StatusTypeDef Status;
	int row=0;
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_RESET);   //SPI CS pull down: enable CS
	byVospiTxDummuyBuf[0]= spi_header_byte;
	Status = HAL_SPI_TransmitReceive(&SPI4_Handler, byVospiTxDummuyBuf, byVospiRxDummuyBuf, VOSPI_TX_DUMMY_LEN, 1000);
	if(Status != HAL_OK)
	{
		return Status;
	}
	while(SPI4_Handler.State == HAL_SPI_STATE_BUSY);
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_SET);   //SPI CS pull up: disable CS
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_RESET);    //SPI CS pull down: enable CS
	for(row = 0; row < VOSPI_COL_SIZE; row++)
	{
		byVospiTxBuf[0]= 0x55;
		Status = HAL_SPI_TransmitReceive(&SPI4_Handler, byVospiTxBuf, byVospiRxBuf, VOSPI_ROW_SIZE, 1000);
		if(Status != HAL_OK)
		{
			return Status;
		}
	#if defined(PRINT_TEMP)
		if(frame_idx%25==0 &&row==96)  //only for TEMP_OUTPUT
		{
			center_temp=(uint16_t)byVospiRxBuf[128*2]+byVospiRxBuf[128*2+1]*256;
			org_kelvin_temp=(float)center_temp/64-273.15;
			printf("center temp is %f\n",org_kelvin_temp);
		}
	#endif
		YUV422ToRGB565(byVospiRxBuf, rgb_buf, VOSPI_ROW_SIZE/2);
		if(spi_header_byte==0xAA)
		{
			LCD_Color_Fill(row,0, row, VOSPI_ROW_SIZE/2 - 1,  rgb_buf);
		}
		else if(spi_header_byte==0xCC)
		{
			LCD_Color_Fill(row+VOSPI_COL_SIZE, 0,  row+VOSPI_COL_SIZE, VOSPI_ROW_SIZE/2 - 1,  rgb_buf);
		}
	}
	while(SPI4_Handler.State == HAL_SPI_STATE_BUSY);
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_SET);   //SPI CS pull up: disable CS
	return HAL_OK;
}



HAL_StatusTypeDef image_frame_get(int frame_idx,int interval)
{
	return get_one_frame(frame_idx,0xAA);
}


HAL_StatusTypeDef temp_frame_get(int frame_idx,int interval)
{
	if(frame_idx==0)
	{
		y16_preview_start(PREVIEW_PATH0,Y16_MODE_TEMPERATURE);
	}
	return get_one_frame(frame_idx,0xAA);
}


HAL_StatusTypeDef image_and_temp_frame_interval_get(int frame_idx,int interval)
{
	HAL_StatusTypeDef Status;
	Status=get_one_frame(frame_idx,0xAA);
	if(Status != HAL_OK)
	{
		return Status;
	}
	if(frame_idx%interval==0)
	{
		return get_one_frame(frame_idx,0xCC);
	}
	else
	{
		return Status;
	}
}

void set_preview_parameter(uint8_t path, uint8_t source,uint16_t width,uint16_t height,uint8_t fps, uint8_t mode)
{
	preview_start_param.path=path;
	preview_start_param.source=source;
	preview_start_param.width=width;
	preview_start_param.height=height;
	preview_start_param.fps=fps;
	preview_start_param.mode=mode;
}


void select_output_mode(output_mode_t output_mode)
{
	switch(output_mode)
	{
		case IMAGE_OUTPUT:
			spi_frame_get=image_frame_get;
			set_preview_parameter(0,0,256,192,25,8);
			break;
		case TEMP_OUTPUT:
			spi_frame_get=temp_frame_get;
			set_preview_parameter(0,0,256,192,25,8);
			break;
		case IMAGE_AND_TEMP_OUTPUT:
			spi_frame_get=image_and_temp_frame_interval_get;
			set_preview_parameter(0,0,256,384,25,8);
			break;
		default:
			spi_frame_get=image_and_temp_frame_interval_get;
			set_preview_parameter(0,0,256,384,25,8);
			break;
	}
}

int environment_correct_prepare(void)
{
#if defined(ENV_CORRECTION)
		FIL* fftemp;
		u8* read_data;
		int rst;
		u32 bread;
		u32 total,free;
		my_mem_init(SRAMIN);		    //��ʼ���ڲ��ڴ��
		my_mem_init(SRAMEX);		    //��ʼ���ⲿ�ڴ��
		my_mem_init(SRAMDTCM);		    //��ʼ��CCM�ڴ�� 

		fftemp=(FIL*)mymalloc(SRAMEX,sizeof(FIL));	//�����ڴ�	
		read_data=mymalloc(SRAMEX,sizeof(correct_table));//read_data���ֽڿռ�

		while(SD_Init())//��ⲻ��SD��
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Error!");
			delay_ms(500);					
			LCD_ShowString(30,150,200,16,16,"Please Check! ");
			delay_ms(500);
		}
		exfuns_init();							//Ϊfatfs��ر��������ڴ�				 
		f_mount(fs[0],"0:",1); 					//����SD�� 	  
		while(exf_getfree("0:",&total,&free))	//�õ�SD������������ʣ������
		{
			LCD_ShowString(30,150,200,16,16,"SD Card Fatfs Error!");
			delay_ms(200);
			LCD_Fill(30,150,240,150+16,WHITE);	//�����ʾ			  
			delay_ms(200);
		}	
		rst=f_open(fftemp,"0:/tau_H.bin",FA_READ); 
		if(rst!=FR_OK)
		{
			printf("f_open tau_H failed\n");
			goto clean;
		}
		rst=f_read(fftemp,read_data,sizeof(correct_table),(UINT *)&bread);		//��ȡ����	
		if(rst!=FR_OK)
		{
			printf("f_read failed\n");
			goto clean;
		}
		memcpy(correct_table,read_data,sizeof(correct_table));
		printf("correct_table[start]=%d\n",correct_table[0]);
		printf("correct_table[end]=%d\n",correct_table[TAU_TABLE_SIZE-1]);
		f_close(fftemp);	
		read_nuc_parameter();
		calculate_org_env_cali_parameter();
		printf("nuc_table[0]=%d\n", nuc_table[0]);
		printf("EMS=%d\n", org_env_param.EMS);
		printf("TAU=%d\n", org_env_param.TAU);
		printf("TA=%d\n", org_env_param.Ta);
		printf("Tu=%d\n", org_env_param.Tu);
		printf("environment_correct_prepare success\n");
		return SUCCESS;
clean:
		myfree(SRAMEX,fftemp);	//�ͷ��ڴ�
		myfree(SRAMEX,read_data);	//�ͷ��ڴ�
		return FAIL;

#else
		return SUCCESS;
#endif
}

int main(void)
{
	volatile uint32_t row = 0;
	u8 lcd_id[12];
	ir_error_t ret;
	uint32_t frame_idx = 0;
	Cache_Enable();                 //��L1-Cache
	HAL_Init();				        //��ʼ��HAL��
	Stm32_Clock_Init(432,25,2,9);   //����ʱ��,216Mhz 
	delay_init(216);                //��ʱ��ʼ��
	uart_init(115200);		        //���ڳ�ʼ��
	LED_Init();                     //��ʼ��LED
	KEY_Init();                     //��ʼ������
	SDRAM_Init();                   //��ʼ��SDRAM
	LCD_Init();                     //��ʼ��LCD
	SPI4_Init();                    //��ʼ��SPI
	MX_I2C2_Init();                 //��ʼ��I2C
	POINT_COLOR=RED;	 		
	sprintf((char*)lcd_id,"LCD ID:%04X",lcddev.id);
	LCD_ShowString(30,80,240,24,24,"LTDC TEST"); 
	LCD_ShowString(30,130,240,24,24,lcd_id);
	delay_ms(1000);	
	LCD_Clear(WHITE);					//clear LCD
    vdcmd_init_by_type(VDCMD_I2C_VDCMD);//register vender command 
	select_output_mode(IMAGE_AND_TEMP_OUTPUT);    //select output mode
	while(KEY_Scan(0)!=KEY1_PRES)
	{
		LCD_ShowString(40,120,200,24,24,"KEY1: Start While!!");
	}
	LCD_Clear(BLACK);

	ret=preview_start(&preview_start_param);
	if(environment_correct_prepare()!=SUCCESS)
	{
		printf("environment_correct_prepare failed\n");
	}
	printf("preview start result=%d\n",ret);
	while(1)
	{	
		handle_uart_cmd();
		spi_frame_get(frame_idx,1); //only  IMAGE_AND_TEMP_OUTPUT need modify interval
		frame_idx++;
	}
	return 0;
}
#elif defined(UPDATE_FW)

int main(void)
{
	int rst;
	u32 total,free;
	Cache_Enable();                 //��L1-Cache
	MPU_Memory_Protection();        //������ش洢����
	HAL_Init();				        //��ʼ��HAL��
	Stm32_Clock_Init(432,25,2,9);   //����ʱ��,216Mhz 
	delay_init(216);                //��ʱ��ʼ��
	uart_init(115200);		        //���ڳ�ʼ��
	//usmart_dev.init(108); 		    //��ʼ��USMART
	LED_Init();                     //��ʼ��LED
	KEY_Init();                     //��ʼ������
	SDRAM_Init();                   //��ʼ��SDRAM
	LCD_Init();                     //��ʼ��LCD
	//W25QXX_Init();				    //��ʼ��W25Q256
	my_mem_init(SRAMIN);		    //��ʼ���ڲ��ڴ��
	my_mem_init(SRAMEX);		    //��ʼ���ⲿ�ڴ��
	my_mem_init(SRAMDTCM);		    //��ʼ��CCM�ڴ�� 
	MX_I2C2_Init();                 //��ʼ��I2C
	
	POINT_COLOR=RED;
	LCD_ShowString(30,50,200,16,16,"Apollo STM32F4/F7"); 
	LCD_ShowString(30,70,200,16,16,"FATFS TEST");	
	LCD_ShowString(30,90,200,16,16,"ATOM@ALIENTEK");
	LCD_ShowString(30,110,200,16,16,"2016/7/15");	 	 
	LCD_ShowString(30,130,200,16,16,"Use USMART for test");	      
	while(SD_Init())//��ⲻ��SD��
	{
		LCD_ShowString(30,150,200,16,16,"SD Card Error!");
		delay_ms(500);					
		LCD_ShowString(30,150,200,16,16,"Please Check! ");
		delay_ms(500);
		LED0_Toggle;//DS0��˸
	}
	vdcmd_init_by_type(VDCMD_I2C_VDCMD);

	//FTL_Init();
	exfuns_init();							//Ϊfatfs��ر��������ڴ�				 
	f_mount(fs[0],"0:",1); 					//����SD�� 
	LCD_Fill(30,150,240,150+16,WHITE);		//�����ʾ			  
	while(exf_getfree("0:",&total,&free))	//�õ�SD������������ʣ������
	{
		LCD_ShowString(30,150,200,16,16,"SD Card Fatfs Error!");
		delay_ms(200);
		LCD_Fill(30,150,240,150+16,WHITE);	//�����ʾ			  
		delay_ms(200);
		LED0_Toggle;//DS0��˸
	}	
	while(KEY_Scan(0)!=KEY1_PRES)
	{
		LCD_ShowString(40,200,200,24,24,"KEY1:Start update");
	}	
	LCD_Fill(40,200,240,200+24,WHITE);	//�����ʾ												  			    
	POINT_COLOR=BLUE;//��������Ϊ��ɫ	   
	rst=update_firmware("0:/RS001_FW_new.bin");
	if(rst!=SUCCESS)
	{
		printf("update_firmware failed\n");
	}
	LCD_ShowString(30,170,200,16,16,"update finished!");	      
	while(1)
	{
		delay_ms(200);		 			   
	} 					  	       		  	       
	return 0;			  	       
}
#endif





